from setuptools import setup

setup(
    name='python_programming',
    version='',
    packages=['lesson_package', 'lesson_package.talk', 'lesson_package.tools'],
    url='https://www.goo.ne.jp',
    license='free',
    author='akimichi',
    author_email='',
    description='1.0.0'
)
