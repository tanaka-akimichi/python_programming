from lesson_package.tools import utils

def sing():
    return 'SSSSSSSSSSSSSSSSS'


def cry():
    return utils.say_twice('XXXXXXXXXXX')



