def say_twice(word):
    return (word + '!') * 2
